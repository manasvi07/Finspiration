export default COGNITO = {
  REGION: "us-east-1",
  USER_POOL_ID: "us-east-1_bC5q77fwk",
  APP_CLIENT_ID: "4lkdo84m3ko27535ntvupmuhvi",
};